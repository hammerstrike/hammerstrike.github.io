# admin-nutrimeals
Nutrimeals admin module [for personal project]
