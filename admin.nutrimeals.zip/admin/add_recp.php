<?php
    include("connection/connection.php");

    $sql_get_all_recp = "SELECT `recp_id`, `recp_name`, `recp_ingredients`, `recp_image`, `recp_isactive`, `recp_created_date`, `recp_created_by`, `recp_modified_date`, `recp_modified_by` 
                         FROM `tbl_recipes`";

    $res_get_all_recp = mysqli_query($mysqli, $sql_get_all_recp);

    $arr_get_all_recp = array();

    while($row_get_all_recp = mysqli_fetch_array($res_get_all_recp))
    {
        $arr_get_all_recp[] = $row_get_all_recp;
    }

    foreach ($arr_get_all_recp as $vals) 
    {
        echo $vals['recp_id'].'<br />';
        echo $vals['recp_name'].'<br />';
        echo $vals['recp_ingredients'].'<br />';
        echo $vals['recp_image'].'<br />';
        echo $vals['recp_isactive'].'<br />';
    }
?>

<?php
    // Insert any new image into database
    /*if (isset($_REQUEST['completed']) && $_GET['completed'] == 1)
    {
        echo $_REQUEST['completed'];
        exit(0);
        // Need to add - check for large upload. Otherwise the code
        // will just duplicate old file ;-)
        // ALSO - note that latest.img must be public write and in a
        // live appliaction should be in another (safe!) directory.
        move_uploaded_file($_FILES['imagefile']['tmp_name'],"latest.img");
        $instr = fopen("latest.img","rb");
        $image = addslashes(fread($instr,filesize("latest.img")));
        if (strlen($image) < 149000)
        {
            mysqli_query("INSERT INTO `tbl_recipes`(`recp_name`, `recp_ingredients`, `recp_image`, `recp_isactive`, `recp_created_date`, `recp_created_by`) 
                          VALUES (\"".$_REQUEST['recp_name']."\", \"".$_REQUEST['recp_ingredients']."\", \"".$image."\", '0', NOW(), 'Prathamesh')");
        }
        else
        {
            $errmsg = "Too large!";
        }
    }
    else
    {
        echo 'Opppsss';
    }*/
?>

<?php
    if(isset($_REQUEST['submit']) && $_REQUEST['submit'] == 'Create' && isset($_FILES['uploaded']['name']))
    {
       // echo $_FILES['uploaded']['name'];
        //echo 'Hi';
        //exit(0);
        $path 	= "images/new_recipes/";
        
        $name 	= $_FILES['uploaded']['name'];
		$size 	= $_FILES['uploaded']['size'];

        $recp_name = $_REQUEST['recp_name'];
        $recp_ingredients = $_REQUEST['recp_ingredients'];
        
        if (strlen($name))
        {
            $valid_formats 		= array("jpg", "jpeg", "png", "gif");
			list($txt, $ext) 	= explode(".", $name);
            
            if (in_array($ext,$valid_formats))
            {
               
                
                if ($size < 1024000)
                {
                    //var_dump($mysqli) ;
                   
                    //$actual_image_name 	= get_auto_next_id('tbl_recipes',$mysqli).".".$ext;
                    
                    
                    setlocale(LC_ALL, 'en_US.UTF8');
                    function create_url_slug($str, $replace=array(), $delimiter='-')
                    {
                        if( !empty($replace) ) {
                            $str = str_replace((array)$replace, ' ', $str);
                        }
                        $clean = iconv('UTF-8', 'ASCII//TRANSLIT', $string);
                        $clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $string);
                        $clean = strtolower(trim($clean, '-'));
                        $clean = preg_replace("/[\/_|+ -]+/", '-', $clean);
                        
                        return $clean;  
                    }
                   
                    $slug_value = create_url_slug($name);

                    $actual_image_name  = time().'_'.$slug_value.'.'.$ext; 
                    $tmp                = $_FILES['uploaded']['tmp_name'];

                    if (move_uploaded_file($tmp, $path.$actual_image_name)) 
                    {
                        $sql_insert_recp = "INSERT INTO `tbl_recipes`(`recp_name`, `recp_ingredients`, `recp_image`, `recp_isactive`, `recp_created_date`, `recp_created_by`) 
                                                              VALUES ('".$recp_name."', '".$recp_ingredients."', '".$actual_image_name."', '0', NOW(), 'Prathamesh')";
                        
                       
                       
                        mysqli_query($mysqli, $sql_insert_recp);
                    }
                    else 
					{
						$err_msg = "Failed to upload image, please try after some time.";
					}
                }
                else 
				{
					$err_msg = "Image file size max 600 KB";
				}
            }
            else 
			{
				$err_msg = "Invalid file format..";	
			}
        }
        else 
		{
				$err_msg = "Please select image..!";
		}
    }
?>

<html>
    <head>
        <title>
            Add Recipes
        </title>
        
        <script type="text/javascript" src="jquery-1.8.0.min.js"></script>
        
        <style>
        #imagePreview {
            width: 180px;
            height: 180px;
            background-position: center center;
            background-size: cover;
            -webkit-box-shadow: 0 0 1px 1px rgba(0, 0, 0, .3);
            display: inline-block;
        }
        </style>

        <script type="text/javascript">
        $(function() {
            $("#uploaded").on("change", function()
            {
                var files = !!this.files ? this.files : [];
                if (!files.length || !window.FileReader) return; // no file selected, or no FileReader support

                if (/^image/.test( files[0].type)){ // only image file
                    var reader = new FileReader(); // instance of the FileReader
                    reader.readAsDataURL(files[0]); // read the local file

                    reader.onloadend = function(){ // set image data as background of div
                        $("#imagePreview").css("background-image", "url("+this.result+")");
                    }
                }
            });
        });
        </script>

    </head>
    
    <body>
        <h2>Add Recipes</h2>
        <form id="frm_addrecp" name="frm_addrecp" method="post" enctype="multipart/form-data">
            <table>
                <tr>
                    <td>Name : </td>
                    <td>
                        <input type="text" name="recp_name" id="recp_name" value="" />
                    </td>
                </tr>
                <tr>
                    <td>Ingredients : </td>
                    <td>
                        <textarea id="recp_ingredients" name="recp_ingredients" cols="40" rows="5"></textarea>
                    </td>
                </tr>
                <tr>
                    <td>Image : </td>
                    <td>
                        <div id="imagePreview"></div>
                        <!--<input id="uploadFile" type="file" name="uploadFile" class="img" />-->
                        <input type="file" name="uploaded" id="uploaded"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="hidden" name="MAX_FILE_SIZE" value="150000">
                        <input type="hidden" name="completed" value="1">
                        <input type="submit" value="Create" name="submit" id="submit" >
                    </td>
                </tr>
            </table>
        </form>
        
        
    </body>
</html>