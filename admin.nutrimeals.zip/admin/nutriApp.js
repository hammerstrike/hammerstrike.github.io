var nutriModal = {};

nutriModal = function(){

}

nutriModal.modal = {
	openModal : function(targetEl){
		$(targetEl).show(0,function(){$(this).addClass('in')});
	},
	closeModal : function(targetEl){
		$(targetEl).removeClass('in').fadeOut(300);
	}
};
(function () {

	var recipes = '';
	var nutriApp = angular.module('nutriApp', ['ngRoute']);

	var controllers = {
		//Main controller for common functionality
		MainController: function ($scope,$http){
			/* init modal */
			$scope.modal = nutriModal.modal;
			$scope.recipes = {};
			$scope.recipes.data = {};

			/* ------------------------
			Ajax call | List all recipes
		   -----------------------*/
			var url = 'nutriCRUD.php';
			var fd = new FormData();
			//data
			var data ={
				crud : "list"
			};

			fd.append("data", JSON.stringify(data));
		    $http.post(url, fd, {
					withCredentials : false,
					headers : {'Content-Type' : undefined},
					transformRequest : angular.identity
				})
				.success(function(data){
					console.log(data);
					//$('#error').html(data);
					$scope.recipes.data = data;

				})
				.error(function(data){
					//console.log(data);
				});
		},

		//List controller for recipes list
		ListController: function ($scope,$http) {

		},

		EditRecipeController : function($scope,$http){
			/* ------------------------
				Ajax call | Edit recipe
			   -----------------------*/

			$scope.editRecipe = function(_id){

				var fd = new FormData();
				var url = 'nutriCRUD.php';
				fd.append('file',$scope.imageFile);
				//sample data
				var data ={
					crud : "edit",
					rId : _id,
					rName : $scope.recipe.name,
					rIngrdient : $scope.recipe.ingredients,
					rIsInactive : $scope.recipe.isInactive
				};
				fd.append("data", JSON.stringify(data));
				loaderController('show');
				$http.post(url, fd, {
					withCredentials : false,
					headers : {'Content-Type' : undefined},
					transformRequest : angular.identity
				})
				.success(function(data){
					console.log(data);
					loaderController('hide');
					if(data.error){
						alertify('warning',data.error);
					}else{
						alertify('success','Recipe edited successfully');
						$scope.recipes.data = data;
					}
					//$scope.recipes = data;
				})
				.error(function(data){
					console.log(data);
					loaderController('hide');
					alertify('warning','Something goes wrong....! Please try again.');
				});
			}
		},
		AddRecipeController : function($scope,recipesService,$http){
			/* ------------------------
				Ajax call | Add recipes
			   -----------------------*/
			$scope.addRecipe = function(){

				var fd = new FormData();
				var url = 'nutriCRUD.php';
				fd.append('file',$scope.imageFile);
				//sample data
				var data ={
					crud : "add",
					rName : $scope.recp_name,
					rIngrdient : $scope.recp_ingredients
				};
				fd.append("data", JSON.stringify(data));

				loaderController('show');
				$http.post(url, fd, {
					withCredentials : false,
					headers : {'Content-Type' : undefined},
					transformRequest : angular.identity
				})
				.success(function(data){
					console.log(data);
					loaderController('hide');
					if(data.error){
						alertify('warning',data.error);
						//$('#error').html(data);
					}else{
						alertify('success','Recipe added successfully');
						$scope.recipes.data = data;
					}

					//console.log(data);
					//$scope.recipes.data = data;

				})
				.error(function(data){
					loaderController('hide');
					alertify('warning','Something goes wrong....! Please try again.');
					//console.log(data);
				});
			}
		},
		ChangePassController:function($scope,$http){

			/* ------------------------------
				Ajax call | Change password
			   ------------------------------*/
			$scope.changePass = function(){

				var url = 'nutriCRUD.php';
				var fd = new FormData();
				//sample data
				var data ={
					crud : "changepass",
					oldpass : $scope.oldpass,
					newpass : $scope.newpass,
					renewpass : $scope.renewpass
				};
				fd.append('data',JSON.stringify(data))

				$http.post(url,fd , {
					withCredentials : false,
					headers : {'Content-Type' : undefined},
					transformRequest : angular.identity
				})
				.success(function(data){
					console.log(data);
				})
				.error(function(data){
					console.log(data);
				});
			}
		}
	};

	function nutriAppRouteConfig($routeProvider) {
		$routeProvider
			.when('/', {
				controller: controllers.MainController,
				templateUrl: 'views/recipeList.html'
			})
			.otherwise({
				redirectTo: '/'
			})
	};

	nutriApp
	.factory('recipesService', function () {
	    var myRecipesService = {
	    	getRecipes: function () {
	            //You could also return specific attribute of the form data instead
	            //of the entire data
	            return recipes;
	        },
	        setRecipes: function (newRecipes) {
	            //You could also set specific attribute of the form data instead
	            recipes = newRecipes
	        }
	    };

	    return myRecipesService;
	})
	.config(nutriAppRouteConfig)
	.directive('uploadfile', function () {
		return {
			restrict: 'A',
			link: function(scope, element) {
				element.bind('click', function(e) {
					var _t = (e.target);
					$(_t).parent().find('input[type="file"]').trigger('click');
					//angular.element(e.target).siblings('#upload').trigger('click');
				});
			}
		};
	})
	.directive("fileselect",function(){
		return {
			link: function($scope,el){
				el.bind("change", function(e){
					var newImage = (e.srcElement || e.target).files[0],
						$targetImg = $(el).parent().parent().find('.recipe-img'),
						reader = new FileReader();
					$scope.imageFile = e.target.files[0];

			        reader.onload = function (e) {
			            $targetImg.attr({'src': e.target.result});
			        }
        			reader.readAsDataURL(newImage);
				});
			}
		};
	})
	.directive('modal', function () {
		return {
			restrict: 'A',
			link: function($scope, el,attr) {

			}
		}
	})
	.directive('modal', function () {
		return {
			restrict: 'A',
			link: function($scope, el,attr) {
				el.on('click',function(){

					switch (attr.moperation){
						case 'open' : {
							$scope.modal.openModal(attr.mtarget);
							el.attr('data-modal','active');
						}
						break;

						case 'close' : {
							$scope.modal.closeModal(attr.mtarget);
							el.attr('data-modal','');
						}
						break;

						case 'toggle' : {
							if(el.attr('data-modal') == ''){
								$scope.modal.openModal(attr.mtarget);
								el.attr('data-modal','active');
							}else{
								$scope.modal.closeModal(attr.mtarget);
								el.attr('data-modal','');
							}
						}
						break;

						default : {
							//do nothing
						}
					}

				});
			}
		};
	});
	nutriApp.controller(controllers);
})();
