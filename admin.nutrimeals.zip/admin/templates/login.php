    <form id="loginForm">
        <div class="logo"></div>
        <div class="login-block">            
            <input type="text" value=""  placeholder="Username" id="username" required="required" autofocus />
            <input type="password" value=""  placeholder="password" id="password" required="required"/>
            <button type="submit">Submit</button>
        </div>
    </form>
    <script src="js/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {

            $('#loginForm').on('submit',function(e){
                e.preventDefault();
                var inputs = {username:$('#username').val(),pass:$('#password').val()};

                $.ajax({
                    type: 'POST',
                    url: "login.php",
                    data: inputs,                    
                    dataType: "json",
                    beforeSend: function(){
                        loaderController('show');
                    },
                    success: function(result){
                        console.log(result);
                        if(result.msg == 'success'){
                            window.location.reload();
                        }else{
                            alertify('warning','Invalid username / password combination');
                        }
                    }
                })
                .done(function(){
                    loaderController('hide');
                });
            });
        });
    </script>
