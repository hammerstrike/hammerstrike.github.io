
<div>
	<div ng-view></div>
</div>
	
<script src="js/jquery.min.js"></script>
<script src="js/angular.js"></script>
<script src="js/ng-upload.js"></script>
<script src="js/angular-route.min.js"></script>	
<script src="nutriApp.js"></script>
