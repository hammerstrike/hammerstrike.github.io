<?php 
	header('Content-Type: application/json');
	include_once 'class.user.php';
	//$result = $_POST;
	$user = new User();
   
    $usrname = $_POST['username'];
    $password = $_POST['pass'];
    extract($_REQUEST);
    $login = $user->check_login($usrname, $password);
   	
   	$result["login"] = $login;
	//add custom names
	if($login){
		session_start();
		$result["msg"] = 'success';			
		$_SESSION['username'] = $_POST['username'];
	}else{
		$result["msg"] =  'fail';
	}

	echo json_encode($result);
	
?>