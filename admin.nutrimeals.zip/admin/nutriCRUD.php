<?php
	session_start();
	function create_url_slug($str, $replace=array(), $delimiter='-'){
        if( !empty($replace) ) {
            $str = str_replace((array)$replace, ' ', $str);
        }
        $clean = iconv('UTF-8', 'ASCII//TRANSLIT', $str);
        $clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $str);
        $clean = strtolower(trim($clean, '-'));
        $clean = preg_replace("/[\/_|+ -]+/", '-', $clean);

        return $clean;
    }
	//return data in json format
	header('Content-Type: application/json');

	//decode data in request
	$req = json_decode($_POST['data']);

	if(isset($req->crud)){

		switch ($req->crud) {

			case 'list':{
					include("connection/connection.php");
					/*$sql_get_all_recp = "SELECT
								`recp_id`, `recp_name`, `recp_ingredients`, `recp_image`, `recp_isactive`, `recp_created_date`, `recp_created_by`, `recp_modified_date`, `recp_modified_by`
	        				FROM
	        					`tbl_recipes`";

				    $res_get_all_recp = mysqli_query($mysqli, $sql_get_all_recp);

				    $arr_get_all_recp = array();

				    while($row_get_all_recp = mysqli_fetch_array($res_get_all_recp)){
				        $arr_get_all_recp[] = $row_get_all_recp;
				    }

					$response = array();
				    foreach ($arr_get_all_recp as $val){
				   		$result = new stdClass();
				       	$result->id				= $val['recp_id'];
				        $result->name 			= $val['recp_name'];
				        $result->ingredients 	= $val['recp_ingredients'];
				        $result->thumb 			= $val['recp_image'];
				        $result->isInactive 	= $val['recp_isactive'];
				        array_push($response,$result);
				    }
				    echo json_encode($response);*/

						if($req->list_active_only){
							$response = listAllRecipes($mysqli,true);
						}else{
							$response = listAllRecipes($mysqli,false);
						}

						//$response = listAactiveRecipes($mysqli);
				    echo json_encode($response);
		    	}
		        break;

		    case 'add':{
		    		$textdata = false;
		    		$imagedata = false;

		    		//check for values present or not
		    		if(isset($req->rName) && isset($req->rIngrdient) ){
				        $textdata = true;
				    }else{
				        $response['data'] = "empty";
				    }

				    if(isset($_FILES['file'])){
				        $imagedata = true;
				    }else{
				        $response['thumb'] = "empty";
				    }

				    if($imagedata==true && $textdata==true){
				    	include("connection/connection.php");
				    	$rName = $req->rName;
				    	$rIngrdient = $req->rIngrdient;
				    	//$result['name'] = $rName = $req->rName;
				        //$result['ingrd'] = $rIngrdient = $req->rIngrdient;

				        $imgFile = $_FILES['file'];

				        //$result['thumb'] = $imgFile;

				        //image path
				       	$path 	= "images/new_recipes/";
				       	//image name
				       	$imgFileName = $_FILES['file']['name'];
				       	//image size
						$imgFilesize = $_FILES['file']['size'];


						if (strlen($imgFileName)){

							$valid_formats 		= array("jpg", "jpeg", "png", "gif");
							list($txt, $ext) 	= explode(".", $imgFileName);

							if (in_array($ext,$valid_formats)){

								if ($imgFilesize < 1024000){

									//$actual_image_name 	= get_auto_next_id('tbl_recipes',$mysqli).".".$ext;
				                    setlocale(LC_ALL, 'en_US.UTF8');

				                    $slug_value = create_url_slug($imgFileName);

				                    $actual_image_name  = time().'_'.$slug_value.'.'.$ext;
				                    $tmp 				= $_FILES['file']['tmp_name'];

				                    if (move_uploaded_file($tmp, $path.$actual_image_name)){

				                        $sql_insert_recp = "INSERT INTO
				                        						`tbl_recipes`(`recp_name`, `recp_ingredients`, `recp_image`, `recp_isactive`, `recp_created_date`, `recp_created_by`)
				                                            VALUES
				                                            	('".$rName."', '".$rIngrdient."', '".$actual_image_name."', '0', NOW(), 'Prathamesh')";

				                        mysqli_query($mysqli, $sql_insert_recp);
				                        //$result['msg'] = "Recipe added successfully";
				                        $response = listAllRecipes($mysqli,false);

				                    }
				                    else{
										$err_msg = "Failed to upload image, please try after some time.";
										$response['error'] = $err_msg;
									}
                				}
							}else{
									$err_msg = "Image file size exceeds";
									$response['error'] = $err_msg;
							}
						}else{
							$err_msg = "Invalid file format..";
							$response['error'] = $err_msg;
						}
				    }else{
				    	$err_msg = "All fields compulsary";
						$response['error'] = $err_msg;
				    }

				    //echo json_encode($result);
				    echo json_encode($response);
		    	}
		        break;

		    case 'edit':{
		    		$textdata = false;
					$imagedata = false;
		    		//check for values present or not
		    		if( isset($req->rName) && ($req->rName != "") && isset($req->rIngrdient) && ($req->rIngrdient != "")){
				        $textdata = true;
				        $imageOk = false;
				        //if image selected
				        if(isset($_FILES['file'])){
					        $imagedata = true;
					        $imgFile = $_FILES['file'];
					        $result['thumb'] = $imgFile;
					        //image path
					       	$path 	= "images/new_recipes/";
					       	//image name
					       	$imgFileName = $_FILES['file']['name'];
					       	//image size
							$imgFilesize = $_FILES['file']['size'];
							$valid_formats 		= array("jpg", "jpeg", "png", "gif");
							list($txt, $ext) 	= explode(".", $imgFileName);

							$imageOk = false;

							if(in_array($ext,$valid_formats) && ($imgFilesize < 1024000)){
								$imageOk = true;
								setlocale(LC_ALL, 'en_US.UTF8');

			                    $slug_value = create_url_slug($imgFileName);

			                    $actual_image_name  = time().'_'.$slug_value.'.'.$ext;
			                    $tmp 				= $_FILES['file']['tmp_name'];

			                    move_uploaded_file($tmp, $path.$actual_image_name);

							}

					    }else{
					        $response['error'] = "Please select image";
					    }

					    include("connection/connection.php");
					   	$query='';
					    $query .= "recp_name='".$req->rName."', ";
							$query .= "recp_ingredients='".$req->rIngrdient."', ";
							if($imageOk) {
							 	$query .= "recp_image='".$actual_image_name."', ";
							}
							$query .= "recp_isactive='".$req->rIsInactive."', ";
							$query .= "recp_modified_date= NOW(), ";
							$query .= "recp_modified_by='Amardeep'";

						$sql_insert_recp = 'UPDATE `tbl_recipes` SET '.$query.' WHERE `recp_id`='.$req->rId;
					    //$sql_insert_recp = "UPDATE `tbl_recipes` SET recp_name='".$req->rName."' WHERE `recp_id` = '".$req->rId."';"

                        mysqli_query($mysqli, $sql_insert_recp);
                        //$result['data'] = $req;
                        //$response['msg'] = "Recipe updated successfully";
                        $response = listAllRecipes($mysqli,false);

				    }else{
				        $response['error'] = "Recipe name / ingredients field(s) compulsary";
				    }

		    		echo json_encode($response);

		    	}
		        break;

		    case 'changepass' : {

		    		if( isset($_SESSION['username']) &&
		    			isset($req->oldpass) &&
		    			isset($req->newpass) &&
		    			isset($req->renewpass)){

		    			include_once 'class.user.php';
		    			$user = new User();

		    			$queryResult = $user->changePassword($_SESSION['username'],$req->oldpass,$req->newpass,$req->renewpass);

						$result['return'] = $queryResult;
						$result['result'] = "success";

					}
					echo json_encode($result);
		    	}
		    	break;

		    default:{

				}
		}
	}

	function listAllRecipes($mysqli,$onlyactive){

		$whClouse = ($onlyactive) ? ' WHERE	`recp_isactive` = 1 ;' : ';';
		$sql_get_all_recp = "SELECT
													`recp_id`, `recp_name`, `recp_ingredients`, `recp_image`, `recp_isactive`, `recp_created_date`, `recp_created_by`, `recp_modified_date`, `recp_modified_by`
	        							FROM
	        								`tbl_recipes`".$whClouse;

	    $res_get_all_recp = mysqli_query($mysqli, $sql_get_all_recp);

	    $arr_get_all_recp = array();

	    while($row_get_all_recp = mysqli_fetch_array($res_get_all_recp)){
	        $arr_get_all_recp[] = $row_get_all_recp;
	    }


		$response = array();
	    foreach ($arr_get_all_recp as $val){
	   		$result = new stdClass();
	       	$result->id				= $val['recp_id'];
	        $result->name 			= $val['recp_name'];
	        $result->ingredients 	= $val['recp_ingredients'];
	        $result->thumb 			= $val['recp_image'];
	        $result->isInactive 	= $val['recp_isactive'];
	        array_push($response,$result);
	    }

	    return $response;
	}

?>
