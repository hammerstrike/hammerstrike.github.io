<?php
    $insession = false; 
    session_start();
    if(isset($_SESSION['username'])){
        $_GET["page"] = 'recipes';
        $insession = true;
    }else{
        $_GET["page"] = 'login';
        $insession = false;
    } 
?>
<!DOCTYPE html>
<html>
<head>
	<title>Nutrimeals | Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link type="text/css" href="css/bootstrap.min.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <?php
        if(!$insession){
            echo '<link type="text/css" href="css/login.css" rel="stylesheet" />';
        }
    ?>    
	<style type="text/css">
        body { 
            padding-top: 20px; 
            padding-bottom: 20px;
            font-family: 'Montserrat';
        }
        
        #alertmsg{display: none; width: 300px; position: fixed; top:50px; left: 50%; margin-left: -150px; z-index: 1;    box-shadow: 0 0 10px 5px;}
        #alertmsg .alert{margin:0 }
        #loader{display: none; position: fixed; width: 100%; height: 100%; z-index: 2; top: 0; left: 0;    background-color: rgba(255,255,255,0.7);}
        #loader img{position: absolute;top:50%; left: 50%;width: 32px;height: 32px;margin-left:-16px;margin-top: -16px;background-color: #fff;    padding: 5px;    border-radius: 4px;    box-shadow: 0 0 10px #E94442;}
        .navbar-default{background-color: #E94442;color: #fff;}
        .navbar-default .navbar-nav>li>a{color: #fff; transition:color 0.5s, background 0.5s;}
        .navbar-default .navbar-nav>li>a:hover{color:#fff;background-color: #C51210;}   
        .navbar-default .navbar-nav>.active>a:hover{color: #fff;background-color:#C13230;} 
        .navbar-default .navbar-nav>.active>a{color: #fff;background-color: #C51210;}
		/* Recipes List */
		.recipesList{}
		.recipesList .recipe.addrecipe{background-color: #DADADA;box-shadow: 0 0 10px;}
		.recipesList .recipe .recipe-image{position: relative;}
		.recipesList .recipe .panel-heading{padding: 2px 5px; border: 1px solid #aaa;width: 100%;    margin: 5px 0;}
		.recipesList .recipe .panel-body{padding: 0 5px;}
		.recipesList .recipe .panel-body textarea{resize: none; width: 100%;}
		.recipesList .recipe .upload { position: absolute; bottom: 5px; right: 5px;}
		.recipesList .recipe .upload img{ transition: background 0.8s; cursor:pointer;  background-color: #fff; border-radius: 4px;    border: 2px solid #000;}
		.recipesList .recipe .upload img:hover{background-color: #E94442;}
		.login-panel{margin-top:10%;box-shadow: 0 10px 10px -10px #aaa;}
        #changePassModal{background-color: rgba(0,0,0,0.7);}
	</style>
</head>
<body ng-app="nutriApp" ng-controller="MainController">
    <div id="loader">
        <img src="images/bx_loader.gif" alt="Loding..." />
    </div>
    <div class="container">
        <?php
        if($insession){?>
            <!-- Static navbar -->
            <nav class="navbar navbar-default">
                <div class="container-fluid">
                    <div class="navbar-header">            
                        <a class="navbar-brand" href="#" style="padding: 0 10px;"><img src="http://nutrimeals.comule.com/images/logo-hr.png" style="max-height: 96px;width: 160px;" alt="Nutrimeals" class="img-responsive"></a>
                    </div>                   
                    <ul class="nav navbar-nav navbar-right">
                        <li class=""><a modal moperation="open" mtarget="#changePassModal" >Change Password</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div><!--/.container-fluid -->
            </nav>
        <?php }?>
        <div id="alertmsg"></div>
    	<?php         

        switch($_GET["page"]){        	
        	case 'login':				       	
        		include_once 'templates/login.php';
        		break;

        	case 'recipes':
        		$pagename = 'Recipes';        		
        		include_once 'templates/recipes.php';
        		break; 

        	default:
        		include_once 'templates/login.php';        		
        		break;
        }  
        ?>
    </div>

    <script type="text/javascript">
        function loaderController(operation){
            switch(operation){
                case 'hide' :{
                    $('#loader').fadeOut(300);
                }
                break;
                case 'show' :{
                    $('#loader').fadeIn(300);
                }
                break;
                default :{
                    //nothing
                }
            }
        }
        function alertify(mode,msg){
            switch(mode){
                case 'success' :{
                    $('#alertmsg')
                        .html('<div class="alert alert-success">'+msg+'</div>')
                        .clearQueue()
                        .slideDown(300)
                        .delay(3000)
                        .slideUp(300);

                }
                break;
                case 'warning' :{
                    $('#alertmsg')
                    .html('<div class="alert alert-danger">'+msg+'</div>')
                    .clearQueue()
                    .slideDown(300)
                    .delay(3000)
                    .slideUp(300);
                }
                break;

                default :{
                    $('#alertmsg')
                    .html('<div class="alert alert-info">'+msg+'</div>')
                    .clearQueue()
                    .slideDown(300)
                    .delay(3000)
                    .slideUp(300);
                }
            }
            
        }
    </script>
</body>
</html>