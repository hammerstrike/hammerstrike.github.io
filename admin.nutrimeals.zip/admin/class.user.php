<?php
    include("connection/connection.php");

    class User
    {
        public $db;
        
        public function __construct(){
            $this->db = new mysqli("localhost","nutrim2e_root","abc123!@#","nutrim2e_nutrimeals_db");
            if(mysqli_connect_errno()) {
                echo "Error: Could not connect to database.";
                exit;
            }
        }

        
        /*** for registration process ***/
        public function reg_user($name, $username, $password, $email)
        {
            $password = md5($password);
            $sql = "SELECT `user_id`, `user_name`, `user_pass`, `fullname`, `user_email`, `user_created_date`, `user_modified_date` 
                    FROM `tbl_user_login` 
                    WHERE `user_name` = '$username'
                        OR `user_email` = '$email'";
            
            //checking if the username or email is available in db
            $check = $this->db->query($sql);
            $count_row = $check->num_rows;
            
            //if the username is not in db then insert to the table
            if ($count_row == 0)
            {
                $sql1 = "INSERT INTO `tbl_user_login`(`user_name`, `user_pass`, `fullname`, `user_email`, `user_created_date`) 
                                              VALUES ('$username', '$password', '$name', '$email', NOW())";
                
                $result = mysqli_query($this->db,$sql1) or die(mysqli_connect_errno()."Data cannot inserted");
                
                return $result;
            }
            else
            {
                return false;
            }
        }
        
        /*** for login process ***/
        public function check_login($emailusername, $password)
        {
            $password = substr(md5($password), 0, 25);
            $sql2 = "SELECT `user_id`, `user_name`, `user_pass`, `fullname`, `user_email`, `user_created_date`, `user_modified_date` FROM `tbl_user_login` WHERE `user_name` = '$emailusername' AND `user_pass` = '$password'";
            
            //checking if the username is available in the table
            $result = mysqli_query($this->db,$sql2);
            $user_data = mysqli_fetch_array($result);
            $count_row = $result->num_rows;
            
            if ($count_row == 1)
            {
                // this login var will use for the session thing
                $_SESSION['login'] = true;
                $_SESSION['user_id'] = $user_data['user_id'];
                return true;
            }
            else
            {
                return false;
            }
            //return $count_row;
            
        }
        
        /*** for showing the username or fullname ***/
        public function get_fullname($user_id)
        {
            $sql3 = "SELECT `user_id`, `user_name`, `user_pass`, `fullname`, `user_email`, `user_created_date`, `user_modified_date` 
                     FROM `tbl_user_login` 
                     WHERE `user_id` = $user_id";
            
            $result = mysqli_query($this->db,$sql3);
            $user_data = mysqli_fetch_array($result);
            echo $user_data['fullname'];
        }
        
        /*** change password ***/
        public function changePassword($username,$oldpass,$newpass,$retypepass){

            if( $retypepass == $newpass){

            }

            $sql_change_pass = "UPDATE tbl_user_login SET user_pass='".substr(md5($newpass), 0, 25)."', user_modified_date = NOW() WHERE user_name = '".$username."' AND user_pass = '".substr(md5($oldpass), 0, 25)."'";

            $res_change_pass = mysqli_query($this->db, $sql_change_pass);
            unset($_SESSION["username"]);
            return $sql_change_pass;

        }

        /*** starting the session ***/
        public function get_session()
        {
            return $_SESSION['login'];
        }
        
        public function user_logout()
        {
            $_SESSION['login'] = FALSE;
            session_destroy();
        }
    }
?>