-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2015 at 08:40 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `nutrimeals_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_recipes`
--

CREATE TABLE IF NOT EXISTS `tbl_recipes` (
  `recp_id` int(11) NOT NULL AUTO_INCREMENT,
  `recp_name` varchar(100) DEFAULT NULL,
  `recp_ingredients` text,
  `recp_image` varchar(50) DEFAULT NULL,
  `recp_isactive` int(11) NOT NULL DEFAULT '0',
  `recp_created_date` datetime DEFAULT NULL,
  `recp_created_by` varchar(25) DEFAULT NULL,
  `recp_modified_date` timestamp NULL DEFAULT NULL,
  `recp_modified_by` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`recp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `tbl_recipes`
--

INSERT INTO `tbl_recipes` (`recp_id`, `recp_name`, `recp_ingredients`, `recp_image`, `recp_isactive`, `recp_created_date`, `recp_created_by`, `recp_modified_date`, `recp_modified_by`) VALUES
(1, 'RICE DHOKLA', 'Rice, buttermilk, oil, sugar, Rai, green chilli, turmeric,salt, red chilli powder, lime,coriander leaves', '1444329735_1jpg.jpg', 0, '2015-10-09 00:12:15', 'Prathamesh', '2015-10-09 18:36:06', 'Amardeep'),
(2, 'HANDWA', 'Handwa flour, onions, cabbage, dudhi grated, carot grated, capsicum, tomato,ground nuts, oil, green chillies, turmeric, til, Rai', '1444331868_2jpg.jpg', 0, '2015-10-09 00:47:48', 'Prathamesh', NULL, NULL),
(3, 'BANANA TIKKI', 'banana, capsicum, cabbage, onions, oil, green chilly, ginger, salt, lemon', '1444331887_3jpg.jpg', 0, '2015-10-09 00:48:07', 'Prathamesh', NULL, NULL),
(4, 'MEXICAN RICE', 'Rice, 3 color bell paper, spring onion, baked beans, tomato, boiled corns, oil/butter, oregano, chilli flakes, salt', '1444331905_4jpg.jpg', 0, '2015-10-09 00:48:25', 'Prathamesh', NULL, NULL),
(5, 'TANGY IDLI', 'Mini idli, tomato, capsicum, onion,boiled, corn, oil, pav bhaji masala, ketchup,salt, coriander', '1444331922_1jpg.jpg', 0, '2015-10-09 00:48:42', 'Prathamesh', NULL, NULL),
(6, 'LAZEEZ PASTA', 'Butter, maida, milk, pepper, oregano, salt, cheese, pasta, bell pepper, sweet corn, onion', '1444331938_2jpg.jpg', 0, '2015-10-09 00:48:58', 'Prathamesh', NULL, NULL),
(7, 'GREEN PARANTHA', 'Green peas, French beans, capsicum, groundnut powder, green chilly, chat masala, paneer, wheat flour, salt, coriander', '1444331955_3jpg.jpg', 0, '2015-10-09 00:49:15', 'Prathamesh', NULL, NULL),
(8, 'RAJMAH WRAP', 'Wheat flour, maize flour, rajmah, coriander, cheese, onions, oil', '1444331978_4jpg.jpg', 0, '2015-10-09 00:49:38', 'Prathamesh', NULL, NULL),
(9, 'KHUBANI PUDDING', 'Marie biscuits, condensed milk, cashew powder, coconut powder,sugar', '1444331996_1jpg.jpg', 0, '2015-10-09 00:49:56', 'Prathamesh', NULL, NULL),
(10, 'DHOKLA SANDWICH', 'Rice, urad dal, buttermilk, coriander leaves, coriander chutney, green chillies, lemon juice, salt, sugar, oil', '1444332011_2jpg.jpg', 0, '2015-10-09 00:50:11', 'Prathamesh', '2015-10-09 18:36:18', 'Amardeep'),
(11, 'SOYABEAN CUTLETS', 'Soyabean granules, onion, potato, Rava, jeera powder, chilli powder, garam masala, ginger garlic paste, chat masala, salt, oil', '1444332025_3jpg.jpg', 0, '2015-10-09 00:50:25', 'Prathamesh', NULL, NULL),
(12, 'NACHANI CHOCOLATE', 'Nachni, date, milk, vanilla essence, choco powder, sugar, oil', '1444332039_4jpg.jpg', 0, '2015-10-09 00:50:39', 'Prathamesh', NULL, NULL),
(13, 'OATS CHOCO BALLS', 'Oats,dry fruits, coco powder, condensed milk', '1444332053_1jpg.jpg', 0, '2015-10-09 00:50:53', 'Prathamesh', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users_login`
--

CREATE TABLE IF NOT EXISTS `tbl_users_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(240) NOT NULL,
  `email` varchar(240) NOT NULL,
  `password` varchar(240) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_login`
--

CREATE TABLE IF NOT EXISTS `tbl_user_login` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(25) DEFAULT NULL,
  `user_pass` varchar(25) DEFAULT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `user_created_date` datetime DEFAULT NULL,
  `user_modified_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_user_login`
--

INSERT INTO `tbl_user_login` (`user_id`, `user_name`, `user_pass`, `fullname`, `user_email`, `user_created_date`, `user_modified_date`) VALUES
(1, 'prathamesh2215', '71fbdd7126e24b983ca7835f8', 'Prathamesh Acharekar', 'prathamesh2215@gmail.com', '2015-09-19 00:00:55', NULL),
(2, 'amar', 'a14706fe2d19864c5cb002e15', 'amar', 'email@email.com', '2015-09-19 12:05:10', '2015-10-04 09:34:06');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
