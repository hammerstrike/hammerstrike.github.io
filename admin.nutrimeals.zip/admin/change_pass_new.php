<?php
	session_start();
	include('connection/connection.php');
?>

<?php
	if(isset($_POST['current_username']) && isset($_POST['oldpass']) && isset($_POST['newpass']) && isset($_POST['renewpass']))
	{
		$sql_change_pass = "UPDATE `tbl_user_login` 
						SET `user_pass`='".$_POST['newpass']."',
							`user_modified_date`=NOW() 
						WHERE `user_name` = '".$_POST['current_username']."'
							AND `user_pass` = '".$_POST['oldpass']."'";

		$res_change_pass = mysqli_query($mysqli, $sql_change_pass);
	}	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Change Password</title>
</head>
<body>
	<h4>Change Password</h4>
	<table>
		<tr>
			<td>
				<label class="">Old Password</label>
			</td>
			<td>
				<input class="" placeholder="Old Password" type="password" id="oldpass" required="required" autofocus>
			</td>
		</tr>
		<tr>
			<td>
				<label class="">New Password</label>
			</td>
			<td>
				<input class="" placeholder="New Password" type="password" id="newpass" required="required">
			</td>
		</tr>
		<tr>
			<td>
				<label class="">Retype New Password</label>
			</td>
			<td>
				<input class="" placeholder="Retype New Password" type="password" id="renewpass" required="required">
			</td>
		</tr>
		<tr>
			<td></td>
			<td>
				<input type="hidden" name="current_username" id="current_username" value="<?php echo $_SESSION['name']; ?>">
				<input type="button" value="Submit" name="chpass" onclick="submitform();" >
			</td>
		</tr>
		<tr>
			<td><span id="err"></span></td>
		</tr>
	</table>
	<script type="text/javascript" src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
	<script type="text/javascript">
		function submitform()
		{
			var current_username = document.getElementById('current_username').value;
			var oldpass = document.getElementById('oldpass').value;
			var newpass = document.getElementById('newpass').value;
			var renewpass = document.getElementById('renewpass').value;

			/*alert(current_username+' '+oldpass+' '+newpass+' '+renewpass);*/

			document.getElementById('oldpass').value = '';
			document.getElementById('newpass').value = '';
			document.getElementById('renewpass').value = '';

			if(oldpass == null)
			{
				alert('Old Password field should not be empty');
				document.getElementById('err').innerHTML = 'Old Password field should not be empty';
				return;
			}
			else if(newpass == null || renewpass == null || newpass != renewpass)
			{
				alert('New Password and Retype New Password field should not be empty');
				document.getElementById('err').innerHTML = 'New Password and Retype New Password field should not be empty';
				return;
			}
			else
			{
				$.ajax({
					type: 'POST',
					url: 'change_pass_new.php',
					data: 'current_username='+current_username+'&oldpass='+oldpass+'&newpass='+newpass+'&renewpass='+renewpass,
					success: function()
					{
						alert('success');
						document.getElementById('err').innerHTML = 'success';
					}
				});
				return;
			}
		}
	</script>
</body>
</html>