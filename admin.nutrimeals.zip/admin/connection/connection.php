<?php

    $live = false;
    if($live){
        $dbname = "nutrim2e_nutrimeals_db";
        $dbuser = "nutrim2e_root";
        $dbpass = "abc123!@#";
    }else{
        $dbname = "nutrimeals_db";
        $dbuser = "root";
        $dbpass = "";
    }

    $mysqli = new mysqli("localhost","nutrim2e_root","abc123!@#","nutrim2e_nutrimeals_db") or die(mysqli_error($mysqli));

    /* All functions defined*/
    function get_auto_next_id($table_name,$conn)
    {   
        
        global $dbname;
        $next_insert_id = 0;
        $table_schema = $dbname;
        /*if ($_SERVER['HTTP_HOST'] == "localhost" || preg_match("/^192\.168\.2.\d+$/",$_SERVER['HTTP_HOST'])) {
            $table_schema = "mystudyc_temp";
        }*/
        $data = mysqli_fetch_array(mysqli_query($conn , "select AUTO_INCREMENT from information_schema.Tables where TABLE_SCHEMA = '".$table_schema."' and TABLE_NAME='".$table_name."'"));
        if (isset($data['AUTO_INCREMENT'])) {
            $next_insert_id = $data['AUTO_INCREMENT'];
        }
        return $next_insert_id;
    }

?>