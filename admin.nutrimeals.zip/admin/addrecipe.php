<?php 
    header('Content-Type: application/json');

    //$postdata = file_get_contents("php://input");
    //$request = json_decode($postdata);  
    $req = json_decode($_POST['data']);

    if( isset($req->rName) && isset($req->rIngrdient) ){
        $result['name'] = $req->rName;
        $result['ingrd'] = $req->rIngrdient;
    }else{
        $result['data'] = "empty";
    }

    if(isset($_FILES['file'])){
        $imgFile = $_FILES['file']['name'];
        $result['thumb'] = $imgFile;
    }else{
        $result['thumb'] = "empty";
    }

    echo json_encode($result);
/*
	include("connection/connection.php");

	if(isset($_REQUEST['submit']) && $_REQUEST['submit'] == 'Create' && isset($_FILES['uploaded']['name'])){
		// echo $_FILES['uploaded']['name'];
        //echo 'Hi';
        //exit(0);

        
        $path 	= "images/new_recipes/";
        
        $name 	= $_FILES['uploaded']['name'];
		$size 	= $_FILES['uploaded']['size'];

        $recp_name = $_REQUEST['recp_name'];
        $recp_ingredients = $_REQUEST['recp_ingredients'];
        
        if (strlen($name)){
            $valid_formats 		= array("jpg", "jpeg", "png", "gif");
			list($txt, $ext) 	= explode(".", $name);
            
            if (in_array($ext,$valid_formats))
            {
                if ($size < 1024000)
                {
                    //var_dump($mysqli) ;                   
                    $actual_image_name 	= get_auto_next_id('tbl_recipes',$mysqli).".".$ext;
                    $tmp 				= $_FILES['uploaded']['tmp_name'];
                                       
                    if (move_uploaded_file($tmp, $path.$actual_image_name)) 
                    {
                        $sql_insert_recp = "INSERT INTO 
                        						`tbl_recipes`(`recp_name`, `recp_ingredients`, `recp_image`, `recp_isactive`, `recp_created_date`, `recp_created_by`) 
                                            VALUES 
                                            	('".$recp_name."', '".$recp_ingredients."', '".$actual_image_name."', '0', NOW(), 'Prathamesh')";
                        
                        mysqli_query($mysqli, $sql_insert_recp);
                    }
                    else 
					{
						$err_msg = "Failed to upload image, please try after some time.";
					}
                }
                else 
				{
					$err_msg = "Image file size exceeds";
				}
            }
            else 
			{
				$err_msg = "Invalid file format..";	
			}
        }
        else 
		{
				$err_msg = "Please select image..!";
		}
    }*/
?>