<div class="responsive-menu">
    <a href="" class="responsive-menu-close"><i class="icon-close"></i></a>
    <nav class="responsive-nav"></nav>
    <!-- end .responsive-nav -->
</div>
<!-- end .responsive-menu -->
<header class="header branded">
    <!-- transparent -->
    <div class="navigation">
        <div class="container clearfix">
            <div class="logo">
                <a href="index.php?page=home"><img src="images/logo-hr.png" alt="Nutrimeals" class="img-responsive"></a>
                
            </div>
            <?php if(!isset($pagename)){}else{ ?>
            <h4 class="page-name-heading hidden-xs"> | &nbsp;<?php echo $pagename; ?></h4>
            <?php }?>
            <!-- end .logo -->
            <!--<nav class="main-nav">
                <ul class="list-unstyled">
                    <li class="home about">
                        <a href="index.php?page=home"><img src="./images/nav-4.png" alt="" class="hidden-xs" /><span class="visible-xs-block">Home</span></a>
                    </li>
                    <li class="recipes">
                        <a href="index.php?page=recipes"><img src="./images/nav-1.png" alt="" class="hidden-xs" /><span class="visible-xs-block">Recipes</span></a>
                    </li>
                    <li class="meal-plan">
                        <a href="index.php?page=meal-plan"><img src="./images/nav-2.png" alt="" class="hidden-xs" /><span class="visible-xs-block">Meal Plan</span></a>
                    </li>
                    <li class="faq">
                        <a href="index.php?page=faq"><img src="./images/nav-3.png" alt="" class="hidden-xs" /><span class="visible-xs-block">FAQs</span></a>
                    </li>
                    <li class="about">
                        <a href="index.php?page=about"><img src="./images/nav-4.png" alt="" class="hidden-xs" /><span class="visible-xs-block">About</span></a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </nav>-->
            <nav class="main-nav">
                <ul class="list-unstyled">
                    <li class="home about">
                        <a <?php echo ($_GET["page"]=='home') ? 'class=active href=javascript:void(0)' :'href=index.php?page=home'; ?>><span class="">Home</span></a>
                    </li>
                    <li class="recipes">
                        <a <?php echo ($_GET["page"]=='recipes') ? 'class=active href=javascript:void(0)' :'href=index.php?page=recipes'; ?>><span class="">Recipes</span></a>
                    </li>
                    <li class="meal-plan">
                        <a <?php echo ($_GET["page"]=='meal-plan') ? 'class=active href=javascript:void(0)' :'href=index.php?page=meal-plan'; ?>><span class="">Meal Plan</span></a>
                    </li>
                    <li class="faq">
                        <a <?php echo ($_GET["page"]=='faq') ? 'class=active href=javascript:void(0)' :'href=index.php?page=faq'; ?>><span class="">FAQs</span></a>
                    </li>
                    <li class="about">
                        <a <?php echo ($_GET["page"]=='about') ? 'class=active href=javascript:void(0)' :'href=index.php?page=about'; ?>><span class="">About</span></a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </nav>
            <!-- end .main-nav -->
            <a href="" class="responsive-menu-open"><i class="fa fa-bars"></i></a>
        </div>
        <!-- end .container -->
    </div>
    <!-- end .navigation -->
</header>
<!-- end .header -->