<?php
    if(!isset($_GET["bgopt"]) ){
        $bgClass = '';
    }else if($_GET["bgopt"] == "opt1"){
        $bgClass = "opt1";
    }else if($_GET["bgopt"] == "opt2"){
        $bgClass = "opt2";
    }else if($_GET["bgopt"] == "opt3"){
        $bgClass = "opt3";
    }else{
        $bgClass = "";
    }
?>


<input type="hidden" id="page-info" data-page="home"/>
<div id="welcome-slider" class="<?php echo $bgClass; ?>">
    <div class="text-center slidee-logo-container">
        <div class="slidee-logo"><img src="images/logo-l.png" alt="Nutrimeals" class="" /></div>
    </div>
    <div class="slides clearfix">
        <div class="slide" style="background-image: url('images/background06.jpg');">
            <div class="inner">

            </div>
            <!-- end .inner -->
        </div>
        <!-- end .slide -->
        <!--<div class="slide" style="background-image: url('images/background01.jpg');">
					<div class="inner">
						
					</div> <!-- end .inner --
				</div> <!-- end .slide -->
    </div>
    <!-- end .slides -->
</div>
<!-- end .welcome-slider -->

<div class="section white section-nutrimeals">
    <div class="inner">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <h2><small>A tiffin service</small>Nutrimeals</h2>
                    <ul class="leaf-list">
                        <li>Nutrimeals is a tiffin service of cooked nutrional meal for primary school children.</li>
                        <li>Children spend most of their time in school, almost about 8-10 hours a day. It is their second home and thus it becomes essential to make sure that they do not miss out on nutritional values when in school.</li>
                        <li>Nowadays, with both the parents working to earn bread and butter, it has become difficult for them to juggle between responsibilities at work and home.</li>
                        <li>NutriMeal wants to help parents and children built hygienic and healthy future by providing nutritional meals for children.</li>
                    </ul>
                </div>
                <!-- end .col-sm-6 -->
                <div class="col-sm-6 hidden-xs">
                    <img src="images/mission.jpg" alt="alt text here" class="img-responsive">
                </div>
                <!-- end .col-sm-6 -->
            </div>
            <!-- end .row -->
        </div>
        <!-- end .container -->
    </div>
    <!-- end .inner -->
</div>
<!-- end .section -->

<div class="section white">
    <div class="partial-background" style="background-image: url('images/bg-2.jpg');"></div><!-- style="background-image: url('images/background04.jpg');" -->
    <div class="inner">
        <div class="container">
            <h2 class="text-center white">Benefits of Nutrimeals</h2>
            <div class="specialties-slider">
                <div class="specialty">
                    <div class="image hidden-xs">
                        <img src="images/ben-1.png" alt="alt text here" class="img-responsive">
                    </div>
                    <!-- end .image -->
                    <h5 class="visible-xs-block">Recipes designed by Dietician.</h5>
                </div>
                <!-- end .specialty -->
                <div class="specialty">
                    <div class="image hidden-xs">
                        <img src="images/ben-2.png" alt="alt text here" class="img-responsive">
                    </div>
                    <!-- end .image -->
                    <h5 class="visible-xs-block">Each recipe has unique benefit to child’s health.</h5>
                </div>
                <!-- end .specialty -->
                <div class="specialty">
                    <div class="image hidden-xs">
                        <img src="images/ben-3.png" alt="alt text here" class="img-responsive">
                    </div>
                    <!-- end .image -->
                    <h5 class="visible-xs-block">Fosters bone development, enhances immunity and reduces susceptibility to disease.</h5>
                </div>
                <!-- end .specialty -->
                <div class="specialty">
                    <div class="image hidden-xs">
                        <img src="images/ben-4.png" alt="alt text here" class="img-responsive">
                    </div>
                    <!-- end .image -->
                    <h5 class="visible-xs-block">NutriMeal will help children to feel better, less irritable and less tensed.</h5>
                </div>
                <!-- end .specialty -->
                <div class="specialty">
                    <div class="image hidden-xs">
                        <img src="images/ben-5.png" alt="alt text here" class="img-responsive">
                    </div>
                    <!-- end .image -->
                    <h5 class="visible-xs-block">Attractive packaging to make child eager to eat the meal.</h5>
                </div>
                <!-- end .specialty -->
                <div class="specialty">
                    <div class="image hidden-xs">
                        <img src="images/ben-6.png" alt="alt text here" class="img-responsive">
                    </div>
                    <!-- end .image -->
                    <h5 class="visible-xs-block">Helps to introduce Good eating Etiquette in children.</h5>
                </div>
                <!-- end .specialty -->
            </div>
            <!-- end .specialty-slider -->
        </div>
        <!-- end .container -->
    </div>
    <!-- end .inner -->
</div>
<!-- end .section -->